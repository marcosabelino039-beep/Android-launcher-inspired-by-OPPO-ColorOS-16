package com.peladagpt.coloros16launcher

import android.content.Intent
import android.content.pm.ResolveInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class LaunchableApp(
    val label: String,
    val packageName: String,
    val resolveInfo: ResolveInfo
)

class MainActivity : ComponentActivity() {
    private fun loadApps(): List<LaunchableApp> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, 0)
            .map {
                LaunchableApp(
                    label = it.loadLabel(packageManager).toString(),
                    packageName = it.activityInfo.packageName,
                    resolveInfo = it
                )
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val apps = loadApps()
        setContent {
            ColorLauncherScreen(
                apps = apps,
                onLaunch = { app ->
                    val launchIntent = packageManager.getLaunchIntentForPackage(app.packageName)
                    if (launchIntent != null) startActivity(launchIntent)
                }
            )
        }
    }
}

@Composable
fun ColorLauncherScreen(
    apps: List<LaunchableApp>,
    onLaunch: (LaunchableApp) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var drawerOpen by remember { mutableStateOf(false) }

    val shownApps = remember(apps, query, drawerOpen) {
        if (!drawerOpen) emptyList()
        else apps.filter { it.label.contains(query, ignoreCase = true) }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF252638), Color(0xFF11121B), Color(0xFF08090E))
                )
            )
            .padding(horizontal = 20.dp, vertical = 24.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Olá", color = Color.White.copy(alpha = 0.72f), fontSize = 15.sp)
                    Text(
                        "Sua tela inicial",
                        color = Color.White,
                        fontSize = 27.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .background(Color.White.copy(alpha = 0.12f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("16", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(Modifier.height(24.dp))

            // Decorative glass-style search surface.
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White.copy(alpha = 0.10f), RoundedCornerShape(22.dp))
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("⌕", color = Color.White.copy(alpha = 0.8f), fontSize = 23.sp)
                Spacer(Modifier.width(10.dp))
                Text(
                    if (drawerOpen) "Pesquisar aplicativos" else "Toque em Aplicativos para abrir a gaveta",
                    color = Color.White.copy(alpha = 0.72f),
                    fontSize = 13.sp
                )
            }

            Spacer(Modifier.height(22.dp))

            if (!drawerOpen) {
                Text("Favoritos", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    listOf("Telefone", "Câmera", "Mensagens", "Config.").forEachIndexed { index, name ->
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .background(Color.White.copy(alpha = 0.09f), RoundedCornerShape(20.dp))
                                .padding(vertical = 16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                Modifier.size(42.dp).background(
                                    listOf(Color(0xFF8E9BFF), Color(0xFFFFB27D), Color(0xFF75D7C0), Color(0xFFC3A0FF))[index],
                                    RoundedCornerShape(15.dp)
                                ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(name.take(1), color = Color(0xFF171824), fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.height(7.dp))
                            Text(name, color = Color.White, fontSize = 10.sp, maxLines = 1)
                        }
                    }
                }

                Spacer(Modifier.height(24.dp))
                Text("Pastas", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    FolderTile("Social", "Mensagens · Redes")
                    FolderTile("Multimídia", "Fotos · Música")
                }

                Spacer(Modifier.weight(1f))
                Button(
                    onClick = { drawerOpen = true },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE7E7F2), contentColor = Color(0xFF171824))
                ) {
                    Text("Aplicativos", fontWeight = FontWeight.SemiBold)
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Todos os aplicativos",
                        color = Color.White,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = { drawerOpen = false }) { Text("Início") }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("Pesquisar") },
                    shape = RoundedCornerShape(18.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color.White.copy(alpha = 0.5f),
                        unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                        focusedPlaceholderColor = Color.White.copy(alpha = 0.5f),
                        unfocusedPlaceholderColor = Color.White.copy(alpha = 0.5f),
                        cursorColor = Color.White
                    )
                )
                Spacer(Modifier.height(12.dp))
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(bottom = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(shownApps, key = { it.packageName }) { app ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onLaunch(app) }
                                .padding(vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(52.dp)
                                    .background(Color.White.copy(alpha = 0.13f), RoundedCornerShape(17.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    app.label.take(1).uppercase(),
                                    color = Color.White,
                                    fontSize = 21.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(
                                app.label,
                                color = Color.White.copy(alpha = 0.9f),
                                fontSize = 10.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RowScope.FolderTile(title: String, subtitle: String) {
    Column(
        modifier = Modifier
            .weight(1f)
            .background(Color.White.copy(alpha = 0.10f), RoundedCornerShape(20.dp))
            .padding(16.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            repeat(4) { index ->
                Box(
                    Modifier
                        .size(22.dp)
                        .background(
                            listOf(Color(0xFF8E9BFF), Color(0xFFFFB27D), Color(0xFF75D7C0), Color(0xFFC3A0FF))[index],
                            RoundedCornerShape(7.dp)
                        )
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(title, color = Color.White, fontWeight = FontWeight.Medium)
        Text(subtitle, color = Color.White.copy(alpha = 0.55f), fontSize = 10.sp)
    }
}
